package com.example.practical7;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

public class MyService extends Service {

    private Handler handler;
    private Runnable runnable;

    private int interval = 5000; // 5 seconds

    @Override
    public void onCreate() {

        super.onCreate();

        handler = new Handler();

        runnable = new Runnable() {

            @Override
            public void run() {

                Toast.makeText(
                        getApplicationContext(),
                        "Service is running...",
                        Toast.LENGTH_SHORT
                ).show();

                handler.postDelayed(this, interval);
            }
        };
    }

    @Override
    public int onStartCommand(
            Intent intent,
            int flags,
            int startId) {

        handler.post(runnable);

        return START_STICKY;
    }

    @Override
    public void onDestroy() {

        super.onDestroy();

        handler.removeCallbacks(runnable);

        Toast.makeText(
                getApplicationContext(),
                "Service Stopped",
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }
}