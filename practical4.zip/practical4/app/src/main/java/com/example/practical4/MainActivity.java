package com.example.practical4;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    RelativeLayout mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mainLayout = findViewById(R.id.mainLayout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.color_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.red) {
            mainLayout.setBackgroundColor(Color.RED);
            return true;

        } else if (id == R.id.green) {
            mainLayout.setBackgroundColor(Color.GREEN);
            return true;

        } else if (id == R.id.blue) {
            mainLayout.setBackgroundColor(Color.BLUE);
            return true;

        } else if (id == R.id.yellow) {
            mainLayout.setBackgroundColor(Color.YELLOW);
            return true;

        } else if (id == R.id.white) {
            mainLayout.setBackgroundColor(Color.WHITE);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}