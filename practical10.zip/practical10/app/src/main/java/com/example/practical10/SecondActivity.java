package com.example.practical10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_second);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        int count = getIntent().getIntExtra(
                "count",
                0
        );

        ArrayList<String> items =
                new ArrayList<>();

        for (int i = 1; i <= count; i++) {

            items.add("Item " + i);
        }

        adapter = new ItemAdapter(items);

        recyclerView.setAdapter(adapter);
    }
}