package com.example.practical10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText numberInput;
    Button generateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        numberInput = findViewById(R.id.numberInput);
        generateBtn = findViewById(R.id.generateBtn);

        generateBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String numStr =
                        numberInput.getText().toString().trim();

                if (!numStr.isEmpty()) {

                    int number = Integer.parseInt(numStr);

                    Intent intent = new Intent(
                            MainActivity.this,
                            SecondActivity.class
                    );

                    intent.putExtra("count", number);

                    startActivity(intent);
                }
            }
        });
    }
}