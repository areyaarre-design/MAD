package com.example.practical10;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter
        extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private ArrayList<String> items;

    public ItemAdapter(ArrayList<String> items) {

        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(
                        R.layout.item_row,
                        parent,
                        false
                );

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position) {

        holder.textView.setText(
                items.get(position)
        );
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    public static class ViewHolder
            extends RecyclerView.ViewHolder {

        TextView textView;

        public ViewHolder(View itemView) {

            super(itemView);

            textView = itemView.findViewById(
                    R.id.itemText
            );
        }
    }
}