package com.example.practical6;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView tvProgress;
    private Button btnStart;

    private int progressStatus = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        tvProgress = findViewById(R.id.tvProgress);
        btnStart = findViewById(R.id.btnStart);

        btnStart.setOnClickListener(v -> startTask());
    }

    private void startTask() {

        progressStatus = 0;

        progressBar.setProgress(progressStatus);
        tvProgress.setText("Progress: 0%");

        new Thread(() -> {

            while (progressStatus < 100) {

                progressStatus++;

                handler.post(() -> {

                    progressBar.setProgress(progressStatus);

                    tvProgress.setText(
                            "Progress: " + progressStatus + "%"
                    );
                });

                try {

                    Thread.sleep(50);

                } catch (InterruptedException e) {

                    e.printStackTrace();
                }
            }

            handler.post(() ->
                    tvProgress.setText(
                            "Task Completed Successfully!"
                    )
            );

        }).start();
    }
}