package com.example.practical8;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_NOTIF = 1001;

    private EditText etLower, etUpper;
    private TextView tvStatus, tvResults;

    private final ResultReceiver receiver =
            new ResultReceiver(new Handler(Looper.getMainLooper())) {

                @Override
                protected void onReceiveResult(
                        int resultCode,
                        Bundle resultData) {

                    if (resultCode == PrimeService.RESULT_PROGRESS) {

                        int checked = resultData.getInt("checked");
                        int total = resultData.getInt("total");

                        tvStatus.setText(
                                "Status: Checking "
                                        + checked
                                        + " / "
                                        + total
                        );

                    } else if (resultCode == PrimeService.RESULT_PRIME_FOUND) {

                        int prime = resultData.getInt("prime");

                        appendPrime(prime);

                    } else if (resultCode == PrimeService.RESULT_DONE) {

                        int count = resultData.getInt("count");

                        tvStatus.setText(
                                "Status: Completed. Found "
                                        + count
                                        + " primes."
                        );

                        Toast.makeText(
                                MainActivity.this,
                                "Prime search completed!",
                                Toast.LENGTH_SHORT
                        ).show();

                    } else if (resultCode == PrimeService.RESULT_ERROR) {

                        String msg = resultData.getString("error");

                        tvStatus.setText("Status: Error");

                        Toast.makeText(
                                MainActivity.this,
                                msg,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
            };

    private void appendPrime(int prime) {

        String existing = tvResults.getText().toString();

        if (existing.isEmpty()) {

            tvResults.setText(String.valueOf(prime));

        } else {

            tvResults.append(", " + prime);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        etLower = findViewById(R.id.etLower);
        etUpper = findViewById(R.id.etUpper);

        tvStatus = findViewById(R.id.tvStatus);
        tvResults = findViewById(R.id.tvResults);

        Button btnStart = findViewById(R.id.btnStart);

        maybeRequestNotificationPermission();

        btnStart.setOnClickListener(
                v -> startPrimeSearch()
        );
    }

    private void startPrimeSearch() {

        String lowStr =
                etLower.getText().toString().trim();

        String upStr =
                etUpper.getText().toString().trim();

        if (lowStr.isEmpty() || upStr.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter both bounds.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long lower;
        long upper;

        try {

            lower = Long.parseLong(lowStr);
            upper = Long.parseLong(upStr);

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Please enter valid numbers.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (lower < 2) {
            lower = 2;
        }

        if (upper < lower) {

            Toast.makeText(
                    this,
                    "Upper bound must be >= lower bound.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        tvStatus.setText("Status: Running...");
        tvResults.setText("");

        Intent intent =
                new Intent(this, PrimeService.class);

        intent.putExtra("lower", lower);
        intent.putExtra("upper", upper);
        intent.putExtra("receiver", receiver);

        startService(intent);
    }

    private void maybeRequestNotificationPermission() {

        if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.TIRAMISU) {

            if (checkSelfPermission(
                    Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(
                        new String[]{
                                Manifest.permission.POST_NOTIFICATIONS
                        },
                        REQ_NOTIF
                );
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == REQ_NOTIF
                && (grantResults.length == 0
                || grantResults[0]
                != PackageManager.PERMISSION_GRANTED)) {

            Toast.makeText(
                    this,
                    "Notifications permission denied; completion alert may be silent.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}