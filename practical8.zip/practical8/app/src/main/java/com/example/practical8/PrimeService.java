package com.example.practical8;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ResultReceiver;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class PrimeService extends Service {

    public static final int RESULT_PROGRESS = 1;
    public static final int RESULT_PRIME_FOUND = 2;
    public static final int RESULT_DONE = 3;
    public static final int RESULT_ERROR = 4;

    private static final String CHANNEL_ID =
            "prime_channel_id";

    @Override
    public void onCreate() {

        super.onCreate();

        createNotificationChannel();
    }

    @Override
    public int onStartCommand(
            Intent intent,
            int flags,
            int startId) {

        long lower =
                intent.getLongExtra("lower", 2);

        long upper =
                intent.getLongExtra("upper", 2);

        ResultReceiver receiver =
                intent.getParcelableExtra("receiver");

        new Thread(() -> {

            try {

                runPrimeSearch(
                        lower,
                        upper,
                        receiver
                );

                postCompletionNotification(
                        lower,
                        upper
                );

            } catch (Exception e) {

                if (receiver != null) {

                    Bundle bundle = new Bundle();

                    bundle.putString(
                            "error",
                            e.getMessage()
                    );

                    receiver.send(
                            RESULT_ERROR,
                            bundle
                    );
                }

            } finally {

                stopSelf(startId);
            }

        }).start();

        return START_NOT_STICKY;
    }

    private void runPrimeSearch(
            long lower,
            long upper,
            ResultReceiver receiver) {

        int total =
                (int) Math.max(
                        0,
                        upper - lower + 1
                );

        int checked = 0;
        int found = 0;

        for (long n = lower; n <= upper; n++) {

            if (isPrime(n)) {

                found++;

                if (receiver != null) {

                    Bundle primeBundle =
                            new Bundle();

                    primeBundle.putInt(
                            "prime",
                            (int) n
                    );

                    receiver.send(
                            RESULT_PRIME_FOUND,
                            primeBundle
                    );
                }
            }

            checked++;

            if (receiver != null
                    && checked % 200 == 0) {

                Bundle progressBundle =
                        new Bundle();

                progressBundle.putInt(
                        "checked",
                        checked
                );

                progressBundle.putInt(
                        "total",
                        total
                );

                receiver.send(
                        RESULT_PROGRESS,
                        progressBundle
                );
            }
        }

        if (receiver != null) {

            Bundle doneBundle =
                    new Bundle();

            doneBundle.putInt(
                    "count",
                    found
            );

            receiver.send(
                    RESULT_DONE,
                    doneBundle
            );
        }
    }

    private boolean isPrime(long n) {

        if (n < 2) {
            return false;
        }

        if (n % 2 == 0) {
            return n == 2;
        }

        if (n % 3 == 0) {
            return n == 3;
        }

        long limit =
                (long) Math.sqrt(n);

        for (long i = 5;
             i <= limit;
             i += 6) {

            if (n % i == 0
                    || n % (i + 2) == 0) {

                return false;
            }
        }

        return true;
    }

    private void postCompletionNotification(
            long lower,
            long upper) {

        Context context = this;

        Intent openAppIntent =
                new Intent(
                        context,
                        MainActivity.class
                );

        openAppIntent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        PendingIntent pendingIntent =
                PendingIntent.getActivity(
                        context,
                        0,
                        openAppIntent,
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                                ? PendingIntent.FLAG_IMMUTABLE
                                  | PendingIntent.FLAG_UPDATE_CURRENT
                                : PendingIntent.FLAG_UPDATE_CURRENT
                );

        Notification notification =
                new NotificationCompat.Builder(
                        context,
                        CHANNEL_ID
                )
                        .setSmallIcon(
                                android.R.drawable.ic_dialog_info
                        )
                        .setContentTitle(
                                "Prime search finished"
                        )
                        .setContentText(
                                "Completed for range "
                                        + lower
                                        + " to "
                                        + upper
                        )
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .build();

        NotificationManagerCompat
                .from(context)
                .notify(
                        (int) System.currentTimeMillis(),
                        notification
                );
    }

    private void createNotificationChannel() {

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.O) {

            String name =
                    "Prime Notifications";

            String description =
                    "Notifies when prime search completes";

            int importance =
                    NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            name,
                            importance
                    );

            channel.setDescription(description);

            NotificationManager manager =
                    getSystemService(
                            NotificationManager.class
                    );

            if (manager != null) {
                manager.createNotificationChannel(
                        channel
                );
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}