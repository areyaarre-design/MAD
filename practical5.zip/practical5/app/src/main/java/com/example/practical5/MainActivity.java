package com.example.practical5;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvCounter;
    private Button btnStart, btnStop;

    private Handler handler;
    private int counter = 0;
    private boolean isRunning = false;

    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        tvCounter = findViewById(R.id.tvCounter);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);

        handler = new Handler(Looper.getMainLooper());

        runnable = new Runnable() {
            @Override
            public void run() {

                if (isRunning) {

                    counter++;

                    tvCounter.setText(String.valueOf(counter));

                    handler.postDelayed(this, 1000);
                }
            }
        };

        btnStart.setOnClickListener(v -> {

            if (!isRunning) {

                isRunning = true;

                handler.post(runnable);
            }
        });

        btnStop.setOnClickListener(v -> {

            isRunning = false;

            handler.removeCallbacks(runnable);
        });
    }
}